// This file is automatically rebuilt by the Cesium build process.
var hello_world_index = 3;
var gallery_demos = [{
  "name": "三维热力图",
  "date": 1503564942386,
  "img": "三维热力图.jpg"
}, {
  "name": "车辆轨迹",
  "date": 1503565604743,
  "img": "车辆轨迹.jpg"
}, {
  "name": "飞线",
  "date": 1503565604762,
  "img": "飞线.jpg"
}, {
  "name": "Hello World",
  "date": 1503570390611,
  "img": "Hello World.jpg"
}, {
  "name": "模型点选查询",
  "date": 1504769822801,
  "img": "模型点选查询.jpg"
}, {
  "name": "动态粒子风场",
  "date": 1503565604719,
  "img": "动态粒子风场.jpg"
}, {
  "name": "视域分析",
  "date": 1503642137326,
  "img": "视域分析.jpg"
}];